const checkout = (req,res) => {
    res.render("checkout")
}


module.exports = {
    checkout
}
const carrito = (req,res) => {
    res.render("cart")
}


module.exports = {
    carrito
}
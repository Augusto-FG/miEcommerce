const product = (req,res) => {
    res.render("product")
}


module.exports = {
    product
}
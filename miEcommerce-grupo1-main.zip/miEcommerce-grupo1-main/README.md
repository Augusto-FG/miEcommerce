# miEcommerce-grupo1
## Tecnologías usadas:
* NodeJS
* CSS
* Express
* HTML
* EJS

## Organización
La metodologia que utilizamos para llevar este sprint fue SCRUM. 
Donde la 1ra y 2da HU la hicimos en grupo (los 4).
Para las siguientes HU fueron divididas por cada integrante.

Realizamos daily todos los dias, trabajando en conjunto con el equipo.

## Versionado
Para hacer el seguimiento y versionado de los archivos del sprint utilizamos la herramienta Git en la 
plataforma Github, donde cada integrante posee una rama propia y de ahi fuimos unificando (merge) con la 
rama principal.

## Trello
Utilizado para la los backlog y sprints del proyecto
[Link a Trello](https://trello.com/invite/b/iWaUgJjZ/6848c7f6e05ceca86b9f687dae35ae95/sprint)